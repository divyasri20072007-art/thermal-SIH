const pptxgen = require('pptxgenjs');
const pres = new pptxgen();
pres.layout = 'LAYOUT_16x9'; // 10 x 5.625
pres.title = 'Thermo-Shield India';

const C = { navy: '0B1220', navy2: '16213A', ember: 'F97316', red: 'E11D48', ink: '1E293B', muted: '64748B', tint: 'F1F5F9', warm: 'FFF1E6', white: 'FFFFFF', green: '16A34A', blue: '0284C7', purple: 'A21CAF', yellow: 'EAB308' };
const H = 'Cambria', B = 'Calibri';
const shadow = () => ({ type: 'outer', color: '000000', blur: 8, offset: 2, angle: 90, opacity: 0.12 });

function title(s, text, sub) {
  s.addText(text, { x: 0.5, y: 0.35, w: 9, h: 0.7, fontFace: H, fontSize: 30, bold: true, color: C.ink, margin: 0, isTextBox: true });
  if (sub) s.addText(sub, { x: 0.5, y: 1.0, w: 9, h: 0.4, fontFace: B, fontSize: 14, color: C.muted, margin: 0, isTextBox: true });
}
function circle(s, x, y, d, label, fill, fontSize) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill || C.ember }, line: { color: fill || C.ember } });
  s.addText(String(label), { x, y, w: d, h: d, align: 'center', valign: 'middle', fontFace: B, fontSize: fontSize || 14, bold: true, color: C.white, margin: 0, isTextBox: true });
}
function card(s, x, y, w, h, fill) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill || C.tint }, line: { color: fill || C.tint }, shadow: shadow() });
}
function pageNo(s, n) { s.addText(String(n), { x: 9.0, y: 5.2, w: 0.5, h: 0.25, align: 'right', fontFace: B, fontSize: 10, color: C.muted, margin: 0, isTextBox: true }); }

// ---------- 1. Title ----------
{
  const s = pres.addSlide(); s.background = { color: C.navy };
  // hotspot motif
  [[3.6, 8], [2.7, 16], [1.8, 30], [0.9, 0]].forEach(([d, t], i) => s.addShape(pres.shapes.OVAL, { x: 7.6 - d / 2, y: 2.8 - d / 2, w: d, h: d, fill: { color: i === 3 ? C.ember : C.red, transparency: i === 3 ? 0 : 100 - t }, line: { color: C.navy, transparency: 100 } }));
  s.addText('THERMO-SHIELD INDIA', { x: 0.6, y: 1.5, w: 6.2, h: 0.9, fontFace: H, fontSize: 38, bold: true, color: C.white, margin: 0, isTextBox: true });
  s.addText('AI-powered thermal fire and industrial heat intelligence for all of India', { x: 0.6, y: 2.45, w: 5.6, h: 0.8, fontFace: B, fontSize: 18, color: 'CBD5E1', margin: 0, isTextBox: true });
  s.addText('Real satellite data  ·  Risk analysis  ·  Live alerts', { x: 0.6, y: 3.5, w: 5.6, h: 0.4, fontFace: B, fontSize: 14, italic: true, color: C.ember, margin: 0, isTextBox: true });
  s.addNotes('Thermo-Shield India watches the whole country for heat and fire using NASA satellite data. It tells us what the heat source probably is, how risky it is, who may be exposed, and it sends alerts. Everything uses real data only.');
}

// ---------- 2. Problem ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'The problem', 'Satellites see heat, but heat alone does not tell the full story');
  const rows = [['A hotspot is just a dot', 'It does not say if it is a factory fire, a forest fire, crop burning or a normal gas flare.'],
    ['No idea of danger', 'Officers cannot see how risky it is, whether it is growing, or which way the wind is blowing.'],
    ['No idea who is nearby', 'Villages, towns, hospitals and industries around the fire are not shown.']];
  rows.forEach((r, i) => {
    const y = 1.65 + i * 1.15;
    circle(s, 0.5, y, 0.5, i + 1, C.red);
    s.addText(r[0], { x: 1.2, y: y - 0.05, w: 4.3, h: 0.35, fontFace: B, fontSize: 16, bold: true, color: C.ink, margin: 0, isTextBox: true });
    s.addText(r[1], { x: 1.2, y: y + 0.3, w: 4.3, h: 0.6, fontFace: B, fontSize: 13, color: C.muted, margin: 0, isTextBox: true });
  });
  card(s, 6.0, 1.65, 3.5, 3.1, C.navy);
  s.addText('“A simple fire map is not enough. Decision makers need to know what, how serious, and who is at risk.”', { x: 6.3, y: 1.9, w: 2.9, h: 2.6, fontFace: H, fontSize: 17, italic: true, color: C.white, valign: 'middle', margin: 0, isTextBox: true });
  pageNo(s, 2);
  s.addNotes('NASA gives hotspot points. A point alone does not tell the cause, the danger, or the people nearby. Existing viewers only show dots on a map. That is the gap we fill.');
}

// ---------- 3. Our idea ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Our idea', 'Turn raw satellite hotspots into clear, explained incidents');
  const p = [['Detect', 'Collect real NASA fire detections for all of India', C.red], ['Understand', 'Group them into incidents and find the probable source', C.ember],
    ['Assess', 'Score the risk, track growth, check wind and nearby people', C.purple], ['Act', 'Alert by e-mail, create a PDF report, let an analyst verify', C.green]];
  p.forEach((c, i) => {
    const x = 0.5 + i * 2.3;
    card(s, x, 1.7, 2.1, 3.0);
    circle(s, x + 0.75, 1.95, 0.6, i + 1, c[2], 18);
    s.addText(c[0], { x: x + 0.15, y: 2.7, w: 1.8, h: 0.4, align: 'center', fontFace: H, fontSize: 18, bold: true, color: C.ink, margin: 0, isTextBox: true });
    s.addText(c[1], { x: x + 0.2, y: 3.15, w: 1.7, h: 1.3, align: 'center', fontFace: B, fontSize: 13, color: C.muted, margin: 0, isTextBox: true });
  });
  pageNo(s, 3);
  s.addNotes('Four simple steps: detect, understand, assess, act. The platform is a decision-support tool. It does not replace fire services. It helps them decide faster.');
}

// ---------- 4. How it works ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'How it works', 'One automatic pipeline, from satellite to dashboard');
  const steps = [['Collect', 'NASA FIRMS hotspots, checked and de-duplicated'], ['Group', 'Nearby detections in space and time become one incident'], ['Enrich', 'Location, facilities, land cover, wind, population'],
    ['Classify', 'Probable source with evidence and confidence'], ['Score', 'Risk 0-100, momentum, exposed areas'], ['Deliver', 'Dashboard, alerts, PDF report, verification']];
  steps.forEach((st, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = 0.5 + col * 3.1, y = 1.65 + row * 1.75;
    card(s, x, y, 2.7, 1.45, row === 0 ? C.tint : C.warm);
    circle(s, x + 0.15, y + 0.15, 0.42, i + 1, C.ember, 13);
    s.addText(st[0], { x: x + 0.7, y: y + 0.15, w: 1.9, h: 0.42, valign: 'middle', fontFace: H, fontSize: 16, bold: true, color: C.ink, margin: 0, isTextBox: true });
    s.addText(st[1], { x: x + 0.2, y: y + 0.68, w: 2.35, h: 0.7, fontFace: B, fontSize: 12, color: C.muted, margin: 0, isTextBox: true });
    if (col < 2) s.addText('→', { x: x + 2.7, y: y + 0.45, w: 0.4, h: 0.5, align: 'center', fontFace: B, fontSize: 22, bold: true, color: C.ember, margin: 0, isTextBox: true });
  });
  pageNo(s, 4);
  s.addNotes('The pipeline runs by itself every two hours. It collects hotspots, groups them with a clustering method called DBSCAN, adds map and weather context, classifies the source, scores the risk, and then shows everything on the dashboard.');
}

// ---------- 5. Real data ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Only real data', 'No demo or fake records anywhere. If data is missing, the app says “Unavailable”.');
  const d = [['NASA FIRMS', 'Thermal detections from VIIRS and MODIS satellites'], ['OpenStreetMap', '36 states, 788 districts, factories, roads, hospitals'], ['Open-Meteo', 'Wind speed and direction, current and past'],
    ['Census 2011', 'Settlement populations, always shown as estimates'], ['Sentinel-2 and NASA GIBS', 'Before and after satellite pictures'], ['Platform archive', 'Up to 12 months of past events for recurrence']];
  d.forEach((it, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = 0.5 + col * 3.05, y = 1.75 + row * 1.6;
    card(s, x, y, 2.85, 1.35);
    s.addText(it[0], { x: x + 0.2, y: y + 0.15, w: 2.45, h: 0.4, fontFace: H, fontSize: 15, bold: true, color: C.red, margin: 0, isTextBox: true });
    s.addText(it[1], { x: x + 0.2, y: y + 0.58, w: 2.45, h: 0.7, fontFace: B, fontSize: 12, color: C.ink, margin: 0, isTextBox: true });
  });
  pageNo(s, 5);
  s.addNotes('Every number on screen has a label: observed, calculated, model inference, estimate, human verified, or unavailable. We never invent a fire, a village name, a population number or an image.');
}

// ---------- 6. Live vs historical ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Live data and historical data', 'Always clearly separated');
  card(s, 0.5, 1.6, 4.35, 2.45, 'ECFDF5');
  s.addText('LIVE', { x: 0.75, y: 1.75, w: 3.8, h: 0.45, fontFace: H, fontSize: 22, bold: true, color: C.green, margin: 0, isTextBox: true });
  s.addText([{ text: 'Seen by the satellite in the last 48 hours', options: { bullet: true, breakLine: true } }, { text: 'Shown with a green LIVE badge', options: { bullet: true, breakLine: true } }, { text: 'Only live events can send e-mail alerts', options: { bullet: true } }],
    { x: 0.75, y: 2.3, w: 3.9, h: 1.6, fontFace: B, fontSize: 14, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  card(s, 5.15, 1.6, 4.35, 2.45, 'EFF6FF');
  s.addText('HISTORICAL', { x: 5.4, y: 1.75, w: 3.8, h: 0.45, fontFace: H, fontSize: 22, bold: true, color: C.blue, margin: 0, isTextBox: true });
  s.addText([{ text: 'Older observations, for study and trends', options: { bullet: true, breakLine: true } }, { text: 'Shown with a blue HISTORICAL badge', options: { bullet: true, breakLine: true } }, { text: 'Never triggers an emergency alert', options: { bullet: true } }],
    { x: 5.4, y: 2.3, w: 3.9, h: 1.6, fontFace: B, fontSize: 14, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  card(s, 0.5, 4.3, 9.0, 0.75, C.navy);
  s.addText('12-month rule: the system refuses any thermal data older than one year, and the window moves forward every day.', { x: 0.75, y: 4.3, w: 8.5, h: 0.75, valign: 'middle', fontFace: B, fontSize: 14, color: C.white, margin: 0, isTextBox: true });
  pageNo(s, 6);
  s.addNotes('Every detection stores when the satellite saw it and when we ingested it. Live events become historical automatically after 48 hours. A test proves that a historical critical event sends no e-mail while a live one does.');
}

// ---------- 7. What the user sees ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'What the user sees', 'A web dashboard that works on desktop, tablet and mobile, in light or dark theme');
  const f = [['India map', 'Clustered events, state and district filters'], ['Incident page', 'Summary, timeline, risk, exposure, images'], ['Coordinate analysis', 'Type or click any latitude and longitude'], ['State analytics', 'All states, then district level'],
    ['AI explainability', 'Why the system gave this classification'], ['Human verification', 'Analyst confirms or corrects the AI'], ['PDF reports', '13-section incident report in one click'], ['Settings', 'Alerts, users, data sources']];
  f.forEach((it, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.5 + col * 4.6, y = 1.6 + row * 0.85;
    circle(s, x, y + 0.05, 0.45, i + 1, col === 0 ? C.ember : C.red, 13);
    s.addText(it[0], { x: x + 0.6, y, w: 3.8, h: 0.3, fontFace: B, fontSize: 15, bold: true, color: C.ink, margin: 0, isTextBox: true });
    s.addText(it[1], { x: x + 0.6, y: y + 0.3, w: 3.8, h: 0.3, fontFace: B, fontSize: 12, color: C.muted, margin: 0, isTextBox: true });
  });
  pageNo(s, 7);
  s.addNotes('Walk through the screens in the live demo. The date selector at the top changes the map, charts, lists and analytics together.');
}

// ---------- 8. AI ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'AI classification, done honestly', 'The system never claims a satellite proves the exact cause');
  s.addText('10 possible sources', { x: 0.5, y: 1.55, w: 4.4, h: 0.35, fontFace: H, fontSize: 16, bold: true, color: C.ink, margin: 0, isTextBox: true });
  const cls = ['Industrial fire', 'Persistent industrial heat', 'Wildfire', 'Agricultural burn', 'Gas flare', 'Refinery activity', 'Power plant activity', 'Mining activity', 'Other source', 'Unknown'];
  cls.forEach((c, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.5 + col * 2.25, y = 2.0 + row * 0.48;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.1, h: 0.38, rectRadius: 0.19, fill: { color: C.warm }, line: { color: 'FED7AA' } });
    s.addText(c, { x, y, w: 2.1, h: 0.38, align: 'center', valign: 'middle', fontFace: B, fontSize: 11, color: C.ink, margin: 0, isTextBox: true });
  });
  card(s, 5.3, 1.55, 4.2, 2.0);
  s.addText('Every answer includes', { x: 5.5, y: 1.65, w: 3.8, h: 0.35, fontFace: H, fontSize: 15, bold: true, color: C.ink, margin: 0, isTextBox: true });
  s.addText([{ text: 'Confidence and full probability list', options: { bullet: true, breakLine: true } }, { text: 'Evidence with its data source', options: { bullet: true, breakLine: true } }, { text: 'Why: top contributing factors', options: { bullet: true, breakLine: true } }, { text: 'Uncertainty and human status', options: { bullet: true } }],
    { x: 5.5, y: 2.05, w: 3.8, h: 1.4, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 3, margin: 0, isTextBox: true });
  card(s, 5.3, 3.75, 4.2, 1.2, C.navy);
  s.addText('LightGBM + SHAP is trained only on analyst-verified incidents. Until enough exist, a transparent rule engine is used and clearly labelled.', { x: 5.5, y: 3.75, w: 3.8, h: 1.2, valign: 'middle', fontFace: B, fontSize: 12, color: C.white, margin: 0, isTextBox: true });
  pageNo(s, 8);
  s.addNotes('We did not train a model on fake data. Verified incidents become training samples. An admin must approve a trained model before it is used. Until then the app shows: ML model unavailable, insufficient validated training data, and uses documented rules.');
}

// ---------- 9. Risk & wind ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Risk score and wind-aware exposure', 'Not just a circle around the fire');
  const lv = [['LOW', '0-20', C.green], ['MODERATE', '21-40', '84CC16'], ['MEDIUM', '41-60', C.yellow], ['HIGH', '61-80', C.ember], ['CRITICAL', '81-100', C.red]];
  lv.forEach((l, i) => {
    const y = 1.6 + i * 0.5;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y, w: 1.6 + i * 0.55, h: 0.38, rectRadius: 0.06, fill: { color: l[2] }, line: { color: l[2] } });
    s.addText(l[0], { x: 0.6, y, w: 1.6, h: 0.38, valign: 'middle', fontFace: B, fontSize: 11, bold: true, color: C.white, margin: 0, isTextBox: true });
    s.addText(l[1], { x: 2.2 + i * 0.55, y, w: 0.8, h: 0.38, valign: 'middle', fontFace: B, fontSize: 11, color: C.muted, margin: 0, isTextBox: true });
  });
  s.addText([{ text: '11 factors: heat intensity, growth, persistence, people nearby, wind, industry, history', options: { bullet: true, breakLine: true } }, { text: 'Risk momentum: is it rising or falling, and exactly why', options: { bullet: true } }],
    { x: 0.5, y: 4.2, w: 4.8, h: 0.95, fontFace: B, fontSize: 12, color: C.ink, paraSpaceAfter: 4, margin: 0, isTextBox: true });
  // wind diagram
  card(s, 5.6, 1.6, 3.9, 3.4);
  const cx = 6.6, cy = 3.2;
  s.addShape(pres.shapes.ISOSCELES_TRIANGLE, { x: cx + 1.25 - 0.85, y: cy - 1.25, w: 1.7, h: 2.5, rotate: 270, fill: { color: C.ember, transparency: 65 }, line: { color: C.ember, width: 1, dashType: 'dash' } });
  s.addShape(pres.shapes.OVAL, { x: cx - 0.6, y: cy - 0.6, w: 1.2, h: 1.2, fill: { color: C.red, transparency: 75 }, line: { color: C.red, width: 1 } });
  s.addShape(pres.shapes.OVAL, { x: cx - 0.12, y: cy - 0.12, w: 0.24, h: 0.24, fill: { color: C.red }, line: { color: C.white, width: 1 } });
  s.addShape(pres.shapes.OVAL, { x: 8.55, y: 2.85, w: 0.2, h: 0.2, fill: { color: C.green }, line: { color: C.white, width: 1 } });
  s.addText('village', { x: 8.3, y: 3.08, w: 0.9, h: 0.25, align: 'center', fontFace: B, fontSize: 10, color: C.ink, margin: 0, isTextBox: true });
  s.addText('WIND →', { x: 6.9, y: 1.75, w: 1.6, h: 0.3, align: 'center', fontFace: B, fontSize: 12, bold: true, color: C.blue, margin: 0, isTextBox: true });
  s.addText('Hazard circle + downwind wedge. Areas are “potentially exposed”, population is “estimated”.', { x: 5.8, y: 4.4, w: 3.5, h: 0.5, fontFace: B, fontSize: 10, italic: true, color: C.muted, margin: 0, isTextBox: true });
  pageNo(s, 9);
  s.addNotes('Risk is a weighted score from eleven real factors. When risk changes we show which factor caused how many points. For exposure we use real wind: a hazard circle plus a wedge in the downwind direction, and we list real village and town names from map data.');
}

// ---------- 10. Alerts & security ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Alerts and security', 'Right people, right time, no spam');
  card(s, 0.5, 1.55, 4.35, 3.45);
  s.addText('Live e-mail alerts', { x: 0.75, y: 1.7, w: 3.9, h: 0.4, fontFace: H, fontSize: 18, bold: true, color: C.red, margin: 0, isTextBox: true });
  s.addText([{ text: 'Only for new LIVE events with HIGH or CRITICAL risk', options: { bullet: true, breakLine: true } }, { text: 'No duplicate e-mails: alert log with a cooldown', options: { bullet: true, breakLine: true } }, { text: 'E-mail has location, risk, wind, exposed areas, precautions', options: { bullet: true, breakLine: true } }, { text: 'Never contacts emergency services by itself', options: { bullet: true } }],
    { x: 0.75, y: 2.2, w: 3.9, h: 2.6, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  card(s, 5.15, 1.55, 4.35, 3.45);
  s.addText('Secure access', { x: 5.4, y: 1.7, w: 3.9, h: 0.4, fontFace: H, fontSize: 18, bold: true, color: C.purple, margin: 0, isTextBox: true });
  s.addText([{ text: 'Sign up, then a 6-digit code arrives in Gmail (valid 10 minutes)', options: { bullet: true, breakLine: true } }, { text: 'Three roles: Viewer, Analyst, Admin', options: { bullet: true, breakLine: true } }, { text: 'Strong password hashing and JWT login tokens', options: { bullet: true, breakLine: true } }, { text: 'API keys and passwords stay on the server only', options: { bullet: true } }],
    { x: 5.4, y: 2.2, w: 3.9, h: 2.6, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  pageNo(s, 10);
  s.addNotes('Alerts are decision support, not confirmation of an emergency. Two-step e-mail verification makes sure only real users get in. Viewers can look, analysts can verify, admins manage users, alerts and models.');
}

// ---------- 11. Tech stack ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Technology used');
  const cols = [['Frontend', C.ember, ['React + TypeScript', 'Tailwind CSS', 'Leaflet maps', 'Recharts graphs', 'TanStack Query']], ['Backend', C.red, ['Python FastAPI', 'SQLAlchemy + Alembic', 'DBSCAN clustering', 'LightGBM + SHAP', 'ReportLab PDF', 'APScheduler jobs']], ['Data and DevOps', C.purple, ['PostgreSQL + PostGIS', 'Docker Compose', 'Swagger API docs', '45 automated tests', 'Netlify / Render ready']]];
  cols.forEach((c, i) => {
    const x = 0.5 + i * 3.05;
    card(s, x, 1.35, 2.85, 3.7);
    circle(s, x + 0.2, 1.55, 0.5, i + 1, c[1], 14);
    s.addText(c[0], { x: x + 0.85, y: 1.55, w: 1.9, h: 0.5, valign: 'middle', fontFace: H, fontSize: 17, bold: true, color: C.ink, margin: 0, isTextBox: true });
    s.addText(c[2].map((t, j) => ({ text: t, options: { bullet: true, breakLine: j < c[2].length - 1 } })), { x: x + 0.25, y: 2.25, w: 2.4, h: 2.7, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 5, margin: 0, isTextBox: true });
  });
  pageNo(s, 11);
  s.addNotes('A standard modern stack. PostGIS gives spatial indexes for fast location queries. The whole system runs with one Docker Compose command.');
}

// ---------- 12. Results ----------
{
  const s = pres.addSlide(); s.background = { color: C.navy };
  s.addText('First real run', { x: 0.5, y: 0.4, w: 9, h: 0.7, fontFace: H, fontSize: 30, bold: true, color: C.white, margin: 0, isTextBox: true });
  s.addText('Live NASA feed, 11 September 2026', { x: 0.5, y: 1.05, w: 9, h: 0.4, fontFace: B, fontSize: 14, color: 'CBD5E1', margin: 0, isTextBox: true });
  const st = [['840', 'real detections inside India'], ['389', 'incidents formed automatically'], ['36 + 788', 'states and districts covered'], ['45', 'automated tests passing']];
  st.forEach((v, i) => {
    const x = 0.5 + i * 2.3;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.9, w: 2.1, h: 2.3, rectRadius: 0.08, fill: { color: C.navy2 }, line: { color: C.navy2 } });
    s.addText(v[0], { x, y: 2.15, w: 2.1, h: 0.9, align: 'center', valign: 'middle', fontFace: H, fontSize: i === 2 ? 30 : 44, bold: true, color: C.ember, margin: 0, isTextBox: true });
    s.addText(v[1], { x: x + 0.2, y: 3.15, w: 1.7, h: 0.8, align: 'center', fontFace: B, fontSize: 13, color: 'E2E8F0', margin: 0, isTextBox: true });
  });
  s.addText('Verified end to end: sign up, Gmail code, login, map, incident page, wind exposure, 13-page PDF.', { x: 0.5, y: 4.55, w: 9, h: 0.5, fontFace: B, fontSize: 13, italic: true, color: 'CBD5E1', margin: 0, isTextBox: true });
  pageNo(s, 12);
  s.addNotes('These are real numbers from the first run, not demo numbers. The feed had about four thousand rows for South Asia; the system kept only the 840 inside India and grouped them into 389 incidents in about ten seconds.');
}

// ---------- 13. Demo flow ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Live demo flow', 'What we will show, step by step');
  const d = ['Sign in with a verified account', 'Dashboard: live events across India', 'Filter by state, district, date, risk', 'Open an incident: source, risk, timeline', 'Wind exposure and nearby people', 'Generate the PDF and verify as analyst'];
  s.addShape(pres.shapes.LINE, { x: 1.25, y: 2.35, w: 7.5, h: 0, line: { color: 'CBD5E1', width: 2 } });
  d.forEach((t, i) => {
    const cx = 1.25 + i * 1.5;
    circle(s, cx - 0.25, 2.1, 0.5, i + 1, i % 2 ? C.red : C.ember, 14);
    s.addText(t, { x: cx - 0.7, y: 2.8, w: 1.4, h: 1.3, align: 'center', fontFace: B, fontSize: 12, color: C.ink, margin: 0, isTextBox: true });
  });
  card(s, 0.5, 4.3, 9.0, 0.7, C.warm);
  s.addText('The verified incident is saved as a training sample, so the AI can learn from real, checked cases.', { x: 0.75, y: 4.3, w: 8.5, h: 0.7, valign: 'middle', fontFace: B, fontSize: 13, color: C.ink, margin: 0, isTextBox: true });
  pageNo(s, 13);
  s.addNotes('Keep the demo to about three minutes. Start on the dashboard, pick a live event, show the wind and exposure tab, generate the PDF, then verify as analyst.');
}

// ---------- 14. Limits & future ----------
{
  const s = pres.addSlide(); s.background = { color: C.white };
  title(s, 'Limits and next steps', 'Being honest about what satellites can and cannot do');
  card(s, 0.5, 1.55, 4.35, 3.45);
  s.addText('Limits today', { x: 0.75, y: 1.7, w: 3.9, h: 0.4, fontFace: H, fontSize: 18, bold: true, color: C.ink, margin: 0, isTextBox: true });
  s.addText([{ text: 'A hotspot does not prove a fire or its cause', options: { bullet: true, breakLine: true } }, { text: 'Population is from Census 2011, shown as estimate', options: { bullet: true, breakLine: true } }, { text: 'Wind is a weather-model value, not a site sensor', options: { bullet: true, breakLine: true } }, { text: 'ML model waits for enough verified incidents', options: { bullet: true } }],
    { x: 0.75, y: 2.2, w: 3.9, h: 2.6, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  card(s, 5.15, 1.55, 4.35, 3.45, C.warm);
  s.addText('Next steps', { x: 5.4, y: 1.7, w: 3.9, h: 0.4, fontFace: H, fontSize: 18, bold: true, color: C.red, margin: 0, isTextBox: true });
  s.addText([{ text: 'Train LightGBM once verified data grows', options: { bullet: true, breakLine: true } }, { text: 'NASA key for the full 12-month archive', options: { bullet: true, breakLine: true } }, { text: 'Newer population and land-cover layers', options: { bullet: true, breakLine: true } }, { text: 'SMS and WhatsApp alert channels', options: { bullet: true } }],
    { x: 5.4, y: 2.2, w: 3.9, h: 2.6, fontFace: B, fontSize: 13, color: C.ink, paraSpaceAfter: 6, margin: 0, isTextBox: true });
  pageNo(s, 14);
  s.addNotes('We show limits openly because this is a safety tool. Every output needs field verification by authorised people.');
}

// ---------- 15. Close ----------
{
  const s = pres.addSlide(); s.background = { color: C.navy };
  [[3.0, 10], [2.1, 20], [1.2, 0]].forEach(([d, t], i) => s.addShape(pres.shapes.OVAL, { x: 5 - d / 2, y: 1.55 - d / 2 + 0.2, w: d, h: d, fill: { color: i === 2 ? C.ember : C.red, transparency: i === 2 ? 0 : 100 - t }, line: { color: C.navy, transparency: 100 } }));
  s.addText('Thank you', { x: 0.5, y: 3.0, w: 9, h: 0.8, align: 'center', fontFace: H, fontSize: 40, bold: true, color: C.white, margin: 0, isTextBox: true });
  s.addText('Detect  ·  Understand  ·  Assess  ·  Act', { x: 0.5, y: 3.8, w: 9, h: 0.4, align: 'center', fontFace: B, fontSize: 16, italic: true, color: C.ember, margin: 0, isTextBox: true });
  s.addText('Decision-support information. Always verify with authorised field personnel.', { x: 0.5, y: 4.6, w: 9, h: 0.4, align: 'center', fontFace: B, fontSize: 12, color: 'CBD5E1', margin: 0, isTextBox: true });
  s.addNotes('Questions welcome.');
}

pres.writeFile({ fileName: process.argv[2] || 'ThermoShield_India_Presentation.pptx' }).then((f) => console.log('wrote', f));
