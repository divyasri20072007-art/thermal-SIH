"""Brevo (HTTPS) e-mail provider - for hosts that block outbound SMTP ports (e.g. Render free instances).
Set BREVO_API_KEY and EMAIL_FROM (a sender verified in Brevo, which may be your Gmail address)."""
from __future__ import annotations

import logging

import httpx

from ...config import settings
from .base import EmailMessage, EmailProvider, EmailResult

log = logging.getLogger("thermoshield.email.brevo")


class BrevoProvider(EmailProvider):
    name = "brevo"

    def configured(self) -> bool:
        return bool(settings.brevo_api_key and settings.email_from)

    def send(self, message: EmailMessage) -> EmailResult:
        body = {"sender": {"name": "Thermo-Shield India", "email": settings.email_from}, "to": [{"email": t} for t in message.to],
                "subject": message.subject, "textContent": message.text}
        if message.html:
            body["htmlContent"] = message.html
        try:
            r = httpx.post("https://api.brevo.com/v3/smtp/email", json=body, headers={"api-key": settings.brevo_api_key, "accept": "application/json"}, timeout=30.0)
            r.raise_for_status()
            return EmailResult(status="sent", detail=f"delivered to {len(message.to)} recipient(s) via Brevo API", provider=self.name)
        except Exception as exc:
            log.error("Brevo send failed: %s", exc)
            return EmailResult(status="failed", detail=str(exc), provider=self.name)
